# User submitted themes

If you submit a theme, please include a comment at the top with your name and email address:

```toml
# Author : Name <email@my.domain>
```

We have a preview page for themes on our [wiki](https://github.com/helix-editor/helix/wiki/Themes)!
